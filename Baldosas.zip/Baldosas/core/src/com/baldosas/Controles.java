package com.baldosas;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;

import java.util.HashMap;
import java.util.Map;

public class Controles implements InputProcessor {

    static class Button {

        Rectangle rect;
        String action;
        boolean pressed;
        Sprite sprite;

        Button(int x, int y, int sx, int sy, String action, Texture texture) {
            rect = new Rectangle(x, y, sx, sy);
            this.action = action;
            pressed = false;
            sprite = new Sprite(texture);
            sprite.setBounds(x, y, sx, sy);
        }
    }

    Map<String, Button> buttons;
    Map<Integer, Button> pointers;
    final OrthographicCamera camera;
    Tablero tablero;

    public Controles(OrthographicCamera camera, Tablero tablero) {
        this.camera = new OrthographicCamera();
        this.camera.setToOrtho(true, 480, 800);
        this.tablero = tablero;
        buttons = new HashMap<>();
        pointers = new HashMap<>();
        Gdx.input.setInputProcessor(this);
    }

    public void addButton(int x, int y, int sx, int sy, String action, Texture texture) {
        Button b = new Button(x, y, sx, sy, action, texture);
        buttons.put(action, b);
    }

    boolean isPressed(String action) {
        return buttons.get(action) != null && buttons.get(action).pressed;
    }

    public void render(Batch batch) {
        batch.begin();
        for (String i : buttons.keySet()) {
            Button b = buttons.get(i);
            b.sprite.setColor(b.pressed ? Color.YELLOW : Color.WHITE);
            b.sprite.draw(batch);
        }
        batch.end();
    }

    @Override
    public boolean keyDown(int keycode) {
        return false;
    }

    @Override
    public boolean keyUp(int keycode) {
        return false;
    }

    @Override
    public boolean keyTyped(char character) {
        return false;
    }

    @Override
    public boolean touchDown(int x, int y, int pointer, int button) {
        Vector3 touchPos = new Vector3();
        touchPos.set(Gdx.input.getX(), Gdx.input.getY(), 0);

        touchPos.y = Gdx.graphics.getHeight() - touchPos.y;

        camera.unproject(touchPos);

        for (String i : buttons.keySet()) {
            if (buttons.get(i).rect.contains(touchPos.x, touchPos.y)) {
                pointers.put(pointer, buttons.get(i));
                buttons.get(i).pressed = true;
                tablero.moveCharacter(i);
            }
        }
        return true;
    }

    @Override
    public boolean touchUp(int x, int y, int pointer, int button) {
        if (pointers.get(pointer) != null) {
            pointers.get(pointer).pressed = false;
            pointers.remove(pointer);
        }
        return true;
    }

    @Override
    public boolean touchCancelled(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {
        Vector3 touchPos = new Vector3();
        touchPos.set(Gdx.input.getX(), Gdx.input.getY(), 0);
        camera.unproject(touchPos);

        for (String i : buttons.keySet()) {
            if (buttons.get(i).rect.contains(touchPos.x, touchPos.y)) {
                if (pointers.get(pointer) != null) {
                    pointers.get(pointer).pressed = false;
                }
                pointers.put(pointer, buttons.get(i));
                buttons.get(i).pressed = true;
            }
        }
        return true;
    }

    @Override
    public boolean mouseMoved(int screenX, int screenY) {
        return false;
    }

    @Override
    public boolean scrolled(float amountX, float amountY) {
        return false;
    }
}