package com.baldosas;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.utils.Array;

public class Tablero extends ApplicationAdapter {
    private ShapeRenderer shapeRenderer;
    private Color[][] tileColors;
    private Color[] singleColorRow;
    private Texture backgroundTexture;
    private SpriteBatch batch;
    private Sprite lifeImage, tvImage, characterImage;

    Controles controles;

    @Override
    public void create() {
        OrthographicCamera camera = new OrthographicCamera();
        camera.setToOrtho(false, 480, 800);
        shapeRenderer = new ShapeRenderer();
        shapeRenderer.setProjectionMatrix(camera.combined);

        initializeTileColors();
        initializeSingleColorRow();

        backgroundTexture = new Texture("background.png");
        batch = new SpriteBatch();

        TextureRegion heart = new TextureRegion(new Texture("life.png"));
        TextureRegion tv = new TextureRegion(new Texture("tv.png"));
        TextureRegion character = new TextureRegion(new Texture("character.png"));

        lifeImage = new Sprite(heart);
        lifeImage.setSize(50, 50);
        lifeImage.setPosition(350,260);

        tvImage = new Sprite(tv);
        tvImage.setSize(150, 100);
        tvImage.setPosition(0,235);

        characterImage = new Sprite(character);
        characterImage.setSize(60,60);
        characterImage.setPosition(0,340);

        controles = new Controles(camera, this);
        controles.addButton(200,210, 80, 80, "Up", new Texture("up_button.png"));
        controles.addButton(120,130, 80, 80, "Left", new Texture("left_button.png"));
        controles.addButton(280,130, 80, 80, "Right", new Texture("right_button.png"));
        controles.addButton(200,50, 80, 80, "Down", new Texture("down_button.jpg"));
    }

    private void initializeTileColors() {
        int rows = 6;
        int cols = 8;
        tileColors = new Color[rows][cols];
        Color[] colors = {Color.PINK, Color.GREEN, Color.RED, Color.YELLOW, Color.ORANGE, Color.PURPLE, Color.BLUE};

        int whiteRow = 5;
        int whiteCol = MathUtils.random(cols - 1);

        Array<Color> colorList = new Array<>(colors);
        colorList.shuffle();

        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                if (row == whiteRow && col == whiteCol) {
                    tileColors[row][col] = Color.WHITE;
                } else if (colorList.size > 0) {
                    tileColors[row][col] = colorList.pop();
                } else {
                    colorList.addAll(colors);
                    colorList.shuffle();
                    tileColors[row][col] = colorList.pop();
                }
            }
        }
    }

    private void initializeSingleColorRow() {
        singleColorRow = new Color[8];
        for (int col = 0; col < 8; col++) {
            singleColorRow[col] = Color.NAVY;
        }
    }

    @Override
    public void render() {
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        batch.begin();
        batch.draw(backgroundTexture, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight() * 0.48f);
        lifeImage.draw(batch);
        tvImage.draw(batch);
        batch.end();

        drawColorGrid(tileColors);
        drawSingleColorRow(singleColorRow);

        batch.begin();
        characterImage.draw(batch);
        batch.end();

        controles.render(batch);
    }

    private void drawColorGrid(Color[][] colors) {
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);

        for (int row = 0; row < colors.length; row++) {
            for (int col = 0; col < colors[0].length; col++) {
                float x = col * (float) 60.0;
                float y = 400 + row * (float) 60.0;

                shapeRenderer.setColor(colors[row][col]);
                shapeRenderer.rect(x, y, (float) 60.0, (float) 60.0);
            }
        }

        shapeRenderer.end();
    }

    private void drawSingleColorRow(Color[] colors) {
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);

        for (int col = 0; col < colors.length; col++) {
            float x = col * (float) 60.0;
            float y = (float) 340.0;

            shapeRenderer.setColor(colors[col]);
            shapeRenderer.rect(x, y, (float) 60.0, (float) 60.0);
        }
        shapeRenderer.end();
    }

    void moveCharacter(String direction) {
        int targetRow = -1;
        int targetCol = -1;

        switch (direction) {
            case "Up":
                targetRow = (int) (((characterImage.getY() - 400) + 60) / 60);
                targetCol = (int) (characterImage.getX() / 60);
                break;
            case "Down":
                targetRow = (int) (((characterImage.getY() - 400) - 60) / 60);
                targetCol = (int) (characterImage.getX() / 60);
                break;
            case "Left":
                targetRow = (int) ((characterImage.getY() - 400) / 60);
                targetCol = (int) ((characterImage.getX() - 60) / 60);
                break;
            case "Right":
                targetRow = (int) ((characterImage.getY() - 400) / 60);
                targetCol = (int) ((characterImage.getX() + 60) / 60);
                break;
        }

        if (targetRow >= 0 && targetRow < tileColors.length &&
                targetCol >= 0 && targetCol < tileColors[0].length &&
                tileColors[targetRow][targetCol].equals(Color.PURPLE)) {
            switch (direction) {
                case "Up":
                    targetRow += 1;
                    break;
                case "Down":
                    targetRow -= 1;
                    break;
                case "Left":
                    targetCol -= 1;
                    break;
                case "Right":
                    targetCol += 1;
                    break;
            }
        }

        if (targetRow >= 0 && targetRow < tileColors.length &&
                targetCol >= 0 && targetCol < tileColors[0].length &&
                tileColors[targetRow][targetCol].equals(Color.RED)) {
            return;
        }

        float newX = targetCol * 60;
        float newY = 400 + targetRow * 60;

        characterImage.setPosition(newX, newY);
    }

    @Override
    public void dispose() {
        shapeRenderer.dispose();
        backgroundTexture.dispose();
        batch.dispose();
    }
}